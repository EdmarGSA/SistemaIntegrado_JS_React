# Sistema Integrado

Projeto React com integração a API fictícia para gestão de módulos.