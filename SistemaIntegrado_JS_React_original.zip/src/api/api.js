import axios from 'axios';

const api = axios.create({ baseURL: 'https://api.exemplo.com' });

export const criarLote = async (dados) => api.post('/lotes', dados);
export default api;