import React from 'react';
function LiberarFuncoesMaster() {
  return <div>Liberar Funções Master</div>;
}
export default LiberarFuncoesMaster;