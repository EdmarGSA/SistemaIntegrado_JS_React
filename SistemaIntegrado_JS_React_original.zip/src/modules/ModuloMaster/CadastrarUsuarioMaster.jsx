import React from 'react';
function CadastrarUsuarioMaster() {
  return <div>Cadastrar Usuário Master</div>;
}
export default CadastrarUsuarioMaster;