import React from 'react';
function RegistrarGTAEntrada() {
  return <div>Registrar GTA Entrada</div>;
}
export default RegistrarGTAEntrada;