import React, { useState } from 'react';
import { criarLote } from '../../api/api';

function CriarLote() {
  const [nome, setNome] = useState('');
  const handleSubmit = async () => {
    const res = await criarLote({ nome });
    alert('Lote criado: ' + res.data.id);
  };
  return (
    <div>
      <input value={nome} onChange={e => setNome(e.target.value)} placeholder='Nome do Lote' />
      <button onClick={handleSubmit}>Criar</button>
    </div>
  );
}
export default CriarLote;