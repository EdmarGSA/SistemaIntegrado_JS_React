import React from 'react';
function ExemploComponente() {
  return <div>Componente Exemplo</div>;
}
export default ExemploComponente;