import React from 'react';
function App() {
  return <div>Sistema Integrado React</div>;
}
export default App;